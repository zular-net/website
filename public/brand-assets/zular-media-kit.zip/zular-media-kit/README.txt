Zular media kit

logos: mark, logo and app icon, as SVG and PNG.
3d: the bolt as GLB, plus PNG renders.
product: sample images. Names and amounts are samples.

Colors: Violet #7A5CFF, Ink #0B0B0F, White #FFFFFF.
Fonts: Inter and IBM Plex Mono.

Please do not recolor, stretch or rotate the logo, or imply a partnership without asking.
